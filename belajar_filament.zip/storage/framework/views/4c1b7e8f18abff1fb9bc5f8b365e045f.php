
                <div class="text-center mt-6">
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        © <?php echo e(date("Y")); ?> WebPKL. All rights reserved.
                    </p>
                </div>
            <?php /**PATH C:\spindo\WebPKL\storage\framework\views/71393ae06af600822a1886e9cdaab58b.blade.php ENDPATH**/ ?>