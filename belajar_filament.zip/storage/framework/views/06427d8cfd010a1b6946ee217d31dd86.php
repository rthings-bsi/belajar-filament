
                <div class="text-center mt-8 space-y-4">
                    <div class="flex items-center justify-center gap-2">
                        <div class="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 dark:via-gray-600 to-transparent"></div>
                        <span class="text-xs font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">WebPKL</span>
                        <div class="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 dark:via-gray-600 to-transparent"></div>
                    </div>
                    <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">
                        © <?php echo e(date("Y")); ?> WebPKL. All rights reserved.
                    </p>
                    <div class="flex items-center justify-center gap-4 text-xs text-gray-400 dark:text-gray-500">
                        <a href="#" class="hover:text-primary-600 dark:hover:text-primary-400 transition">Privacy</a>
                        <span>•</span>
                        <a href="#" class="hover:text-primary-600 dark:hover:text-primary-400 transition">Terms</a>
                        <span>•</span>
                        <a href="#" class="hover:text-primary-600 dark:hover:text-primary-400 transition">Support</a>
                    </div>
                </div>
            <?php /**PATH C:\spindo\WebPKL\storage\framework\views/2edb0d28ddc8e14d071a777061e776af.blade.php ENDPATH**/ ?>