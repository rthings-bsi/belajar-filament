    <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: -1; opacity: 0.1;">
        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0;
                    background-image: radial-gradient(circle at 25% 25%, #667eea 0%, transparent 50%),
                                    radial-gradient(circle at 75% 75%, #764ba2 0%, transparent 50%);">
        </div>
    </div>