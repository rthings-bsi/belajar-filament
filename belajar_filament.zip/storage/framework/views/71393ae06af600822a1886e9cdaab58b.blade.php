
                <div class="text-center mt-6">
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        © {{ date("Y") }} WebPKL. All rights reserved.
                    </p>
                </div>
            