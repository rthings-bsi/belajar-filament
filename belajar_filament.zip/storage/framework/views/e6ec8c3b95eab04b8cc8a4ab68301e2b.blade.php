
                <div class="text-center mt-8 space-y-6 animate-fade-in-up">
                    <div class="flex items-center justify-center gap-3">
                        <div class="h-px flex-1 bg-gradient-to-r from-transparent via-primary-300 dark:via-primary-600 to-transparent"></div>
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 rounded-full bg-primary-500 animate-pulse"></div>
                            <span class="text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-widest">WebPKL 2024</span>
                            <div class="w-2 h-2 rounded-full bg-primary-500 animate-pulse"></div>
                        </div>
                        <div class="h-px flex-1 bg-gradient-to-r from-transparent via-primary-300 dark:via-primary-600 to-transparent"></div>
                    </div>

                    <p class="text-sm text-gray-600 dark:text-gray-300 font-medium flex items-center justify-center gap-2">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clip-rule="evenodd"></path>
                        </svg>
                        © {{ date("Y") }} WebPKL. All rights reserved.
                    </p>

                    <div class="flex items-center justify-center gap-6 text-xs">
                        <a href="#" class="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-400 transition-all duration-300 hover:scale-110 flex items-center gap-1">
                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path></svg>
                            Contact
                        </a>
                        <span class="text-gray-300 dark:text-gray-600">•</span>
                        <a href="#" class="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-400 transition-all duration-300 hover:scale-110 flex items-center gap-1">
                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
                            Help
                        </a>
                    </div>
                </div>

                <style>
                    @keyframes fade-in {
                        from { opacity: 0; transform: translateY(-10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    @keyframes fade-in-up {
                        from { opacity: 0; transform: translateY(10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    .animate-fade-in {
                        animation: fade-in 0.6s ease-out;
                    }
                    .animate-fade-in-up {
                        animation: fade-in-up 0.8s ease-out;
                    }
                </style>
            