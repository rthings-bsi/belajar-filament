
                <div class="footer-container animate-fade-in-up">
                    <div class="divider-section">
                        <div class="divider-line"></div>
                        <span class="divider-text">WEBPKL {{ date("Y") }}</span>
                        <div class="divider-line"></div>
                    </div>

                    <p class="copyright-text">© {{ date("Y") }} WebPKL. All rights reserved.</p>

                    <div class="footer-links">
                        <a href="#" class="footer-link">Privacy Policy</a>
                        <span class="footer-dot">•</span>
                        <a href="#" class="footer-link">Terms of Service</a>
                        <span class="footer-dot">•</span>
                        <a href="#" class="footer-link">Support</a>
                    </div>
                </div>

                <style>
                    :root {
                        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        --glass-bg: rgba(255, 255, 255, 0.1);
                        --glass-border: rgba(255, 255, 255, 0.2);
                    }

                    /* Elegant Background */
                    body {
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        position: relative;
                        overflow-x: hidden;
                    }

                    body::before {
                        content: "";
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background:
                            radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                            radial-gradient(circle at 80% 80%, rgba(138, 80, 174, 0.3) 0%, transparent 50%),
                            radial-gradient(circle at 40% 20%, rgba(102, 126, 234, 0.2) 0%, transparent 50%);
                        z-index: -1;
                        animation: gradient-shift 15s ease infinite;
                    }

                    body::after {
                        content: "";
                        position: fixed;
                        top: -50%;
                        left: -50%;
                        width: 200%;
                        height: 200%;
                        background: repeating-linear-gradient(
                            45deg,
                            transparent,
                            transparent 10px,
                            rgba(255, 255, 255, 0.03) 10px,
                            rgba(255, 255, 255, 0.03) 20px
                        );
                        z-index: -1;
                        animation: pattern-move 20s linear infinite;
                    }

                    /* Logo Animations */
                    .logo-container {
                        position: relative;
                        display: inline-block;
                    }

                    .logo-wrapper {
                        position: relative;
                        width: 100px;
                        height: 100px;
                        background: rgba(255, 255, 255, 0.95);
                        border-radius: 24px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                        animation: float 3s ease-in-out infinite;
                    }

                    .logo-wrapper::before {
                        content: "";
                        position: absolute;
                        inset: -2px;
                        background: linear-gradient(135deg, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.4));
                        border-radius: 24px;
                        opacity: 0.5;
                        filter: blur(20px);
                        z-index: -1;
                        animation: pulse-glow 2s ease-in-out infinite;
                    }

                    .logo-icon {
                        width: 50px;
                        height: 50px;
                        color: #667eea;
                        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
                    }

                    /* Brand Typography */
                    .brand-title {
                        font-size: 2.5rem;
                        font-weight: 800;
                        color: white;
                        margin-bottom: 0.5rem;
                        letter-spacing: -0.02em;
                        text-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                    }

                    .brand-subtitle {
                        font-size: 0.95rem;
                        color: rgba(255, 255, 255, 0.9);
                        font-weight: 500;
                        letter-spacing: 0.02em;
                        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
                    }

                    /* Footer Styles */
                    .footer-container {
                        margin-top: 2rem;
                        text-align: center;
                    }

                    .divider-section {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-bottom: 1rem;
                        gap: 1rem;
                    }

                    .divider-line {
                        flex: 1;
                        height: 1px;
                        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
                        max-width: 100px;
                    }

                    .divider-text {
                        font-size: 0.75rem;
                        font-weight: 700;
                        color: rgba(255, 255, 255, 0.8);
                        letter-spacing: 0.1em;
                    }

                    .copyright-text {
                        font-size: 0.875rem;
                        color: rgba(255, 255, 255, 0.8);
                        margin-bottom: 1rem;
                    }

                    .footer-links {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 0.75rem;
                        font-size: 0.875rem;
                    }

                    .footer-link {
                        color: rgba(255, 255, 255, 0.9);
                        text-decoration: none;
                        transition: all 0.3s ease;
                        position: relative;
                    }

                    .footer-link::after {
                        content: "";
                        position: absolute;
                        bottom: -2px;
                        left: 0;
                        width: 0;
                        height: 2px;
                        background: white;
                        transition: width 0.3s ease;
                    }

                    .footer-link:hover {
                        color: white;
                    }

                    .footer-link:hover::after {
                        width: 100%;
                    }

                    .footer-dot {
                        color: rgba(255, 255, 255, 0.5);
                    }

                    /* Animations */
                    @keyframes fade-in {
                        from {
                            opacity: 0;
                            transform: translateY(-20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    @keyframes fade-in-up {
                        from {
                            opacity: 0;
                            transform: translateY(20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    @keyframes float {
                        0%, 100% {
                            transform: translateY(0px);
                        }
                        50% {
                            transform: translateY(-10px);
                        }
                    }

                    @keyframes pulse-glow {
                        0%, 100% {
                            opacity: 0.5;
                        }
                        50% {
                            opacity: 0.8;
                        }
                    }

                    @keyframes gradient-shift {
                        0%, 100% {
                            opacity: 1;
                        }
                        50% {
                            opacity: 0.8;
                        }
                    }

                    @keyframes pattern-move {
                        0% {
                            transform: translate(0, 0);
                        }
                        100% {
                            transform: translate(50px, 50px);
                        }
                    }

                    .animate-fade-in {
                        animation: fade-in 0.8s ease-out;
                    }

                    .animate-fade-in-up {
                        animation: fade-in-up 0.8s ease-out 0.2s both;
                    }
                </style>
            