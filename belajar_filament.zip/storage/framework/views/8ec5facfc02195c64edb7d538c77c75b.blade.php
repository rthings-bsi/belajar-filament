
                <div class="text-center mt-4 animate-fade-in-up">
                    <div class="d-flex align-items-center justify-content-center mb-3">
                        <hr class="flex-grow-1 mx-2">
                        <span class="small fw-semibold text-muted">WEBPKL 2024</span>
                        <hr class="flex-grow-1 mx-2">
                    </div>

                    <p class="small text-muted mb-3">© {{ date("Y") }} WebPKL. All rights reserved.</p>

                    <div class="d-flex align-items-center justify-content-center gap-3 small">
                        <a href="#" class="text-decoration-none text-muted">Contact</a>
                        <span class="text-muted">•</span>
                        <a href="#" class="text-decoration-none text-muted">Help</a>
                    </div>
                </div>

                <style>
                    @keyframes fade-in {
                        from { opacity: 0; transform: translateY(-10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    @keyframes fade-in-up {
                        from { opacity: 0; transform: translateY(10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    .animate-fade-in {
                        animation: fade-in 0.6s ease-out;
                    }
                    .animate-fade-in-up {
                        animation: fade-in-up 0.8s ease-out;
                    }
                </style>
            