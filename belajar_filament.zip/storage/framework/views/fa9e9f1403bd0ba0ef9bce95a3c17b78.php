
                <div class="footer-container animate-fade-in-up">
                    <div class="divider-section">
                        <div class="divider-line"></div>
                        <span class="divider-text">WEBPKL <?php echo e(date("Y")); ?></span>
                        <div class="divider-line"></div>
                    </div>

                    <p class="copyright-text">© <?php echo e(date("Y")); ?> WebPKL. All rights reserved.</p>

                    <div class="footer-links">
                        <a href="#" class="footer-link">Privacy Policy</a>
                        <span class="footer-dot">•</span>
                        <a href="#" class="footer-link">Terms of Service</a>
                        <span class="footer-dot">•</span>
                        <a href="#" class="footer-link">Support</a>
                    </div>
                </div>

                <style>
                    :root {
                        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        --glass-bg: rgba(255, 255, 255, 0.1);
                        --glass-border: rgba(255, 255, 255, 0.2);
                    }

                    /* Logo Animations */
                    .logo-container {
                        position: relative;
                        display: inline-block;
                    }

                    .logo-wrapper {
                        position: relative;
                        width: 100px;
                        height: 100px;
                        background: var(--primary-gradient);
                        border-radius: 24px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        box-shadow: 0 20px 60px rgba(102, 126, 234, 0.4);
                        animation: float 3s ease-in-out infinite;
                    }

                    .logo-wrapper::before {
                        content: "";
                        position: absolute;
                        inset: -2px;
                        background: var(--primary-gradient);
                        border-radius: 24px;
                        opacity: 0.5;
                        filter: blur(20px);
                        z-index: -1;
                        animation: pulse-glow 2s ease-in-out infinite;
                    }

                    .logo-icon {
                        width: 50px;
                        height: 50px;
                        color: white;
                        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
                    }

                    /* Brand Typography */
                    .brand-title {
                        font-size: 2.5rem;
                        font-weight: 800;
                        background: var(--primary-gradient);
                        -webkit-background-clip: text;
                        -webkit-text-fill-color: transparent;
                        background-clip: text;
                        margin-bottom: 0.5rem;
                        letter-spacing: -0.02em;
                    }

                    .brand-subtitle {
                        font-size: 0.95rem;
                        color: #64748b;
                        font-weight: 500;
                        letter-spacing: 0.02em;
                    }

                    /* Footer Styles */
                    .footer-container {
                        margin-top: 2rem;
                        text-align: center;
                    }

                    .divider-section {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-bottom: 1rem;
                        gap: 1rem;
                    }

                    .divider-line {
                        flex: 1;
                        height: 1px;
                        background: linear-gradient(90deg, transparent, #e2e8f0, transparent);
                        max-width: 100px;
                    }

                    .divider-text {
                        font-size: 0.75rem;
                        font-weight: 700;
                        color: #94a3b8;
                        letter-spacing: 0.1em;
                    }

                    .copyright-text {
                        font-size: 0.875rem;
                        color: #94a3b8;
                        margin-bottom: 1rem;
                    }

                    .footer-links {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 0.75rem;
                        font-size: 0.875rem;
                    }

                    .footer-link {
                        color: #64748b;
                        text-decoration: none;
                        transition: all 0.3s ease;
                        position: relative;
                    }

                    .footer-link::after {
                        content: "";
                        position: absolute;
                        bottom: -2px;
                        left: 0;
                        width: 0;
                        height: 2px;
                        background: var(--primary-gradient);
                        transition: width 0.3s ease;
                    }

                    .footer-link:hover {
                        color: #667eea;
                    }

                    .footer-link:hover::after {
                        width: 100%;
                    }

                    .footer-dot {
                        color: #cbd5e1;
                    }

                    /* Animations */
                    @keyframes fade-in {
                        from {
                            opacity: 0;
                            transform: translateY(-20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    @keyframes fade-in-up {
                        from {
                            opacity: 0;
                            transform: translateY(20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    @keyframes float {
                        0%, 100% {
                            transform: translateY(0px);
                        }
                        50% {
                            transform: translateY(-10px);
                        }
                    }

                    @keyframes pulse-glow {
                        0%, 100% {
                            opacity: 0.5;
                        }
                        50% {
                            opacity: 0.8;
                        }
                    }

                    .animate-fade-in {
                        animation: fade-in 0.8s ease-out;
                    }

                    .animate-fade-in-up {
                        animation: fade-in-up 0.8s ease-out 0.2s both;
                    }
                </style>
            <?php /**PATH C:\spindo\WebPKL\storage\framework\views/06d5539b95955df86eff16ba31072b61.blade.php ENDPATH**/ ?>