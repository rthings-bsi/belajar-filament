
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                <div class="text-center mb-4 animate-fade-in">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-3 bg-primary shadow-lg mb-3" style="width: 80px; height: 80px;">
                        <svg class="text-white" style="width: 40px; height: 40px;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <h1 class="h2 fw-bold text-primary">WebPKL</h1>
                    <p class="text-muted small">Sistem Manajemen Praktik Kerja Lapangan</p>
                </div>
            <?php /**PATH C:\spindo\WebPKL\storage\framework\views/72a16613bd7b0a29d8c91ee87d538d07.blade.php ENDPATH**/ ?>