<?php

namespace App\Filament\Resources\LaporanPackings\Pages;

use App\Filament\Resources\LaporanPackings\LaporanPackingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporanPacking extends CreateRecord
{
    protected static string $resource = LaporanPackingResource::class;
}
