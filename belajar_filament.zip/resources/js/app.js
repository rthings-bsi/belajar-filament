import './bootstrap';
import '../css/app.css';
import '../css/widgets.css';
import './widgets.js';
